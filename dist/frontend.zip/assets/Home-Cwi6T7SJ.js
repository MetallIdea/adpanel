import{a as e,r as t,t as n}from"./jsx-runtime-D662cbmN.js";import{A as r,F as i,R as a,g as o,l as s,u as c}from"./index-Cqzx0AwQ.js";import{t as l}from"./button.esm-DaCGYWHb.js";import{t as u}from"./requests-DHOuYlMN.js";var d=e(t());function f(){return f=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},f.apply(null,arguments)}function p(e){"@babel/helpers - typeof";return p=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},p(e)}function m(e,t){if(p(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t||`default`);if(p(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function h(e){var t=m(e,`string`);return p(t)==`symbol`?t:t+``}function g(e,t,n){return(t=h(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var _=s.extend({defaultProps:{__TYPE:`MeterGroup`,__parentMetadata:null,children:void 0,className:null,values:null,min:0,max:100,orientation:`horizontal`,labelPosition:`end`,labelOrientation:`horizontal`,start:null,end:null,meter:null,labelList:null},css:{classes:{root:function(e){var t=e.props;return[a(`p-metergroup p-component`,{"p-metergroup-horizontal":t.orientation===`horizontal`,"p-metergroup-vertical":t.orientation===`vertical`})]},metercontainer:`p-metergroup-meter-container`,meter:`p-metergroup-meter`,labellist:function(e){var t=e.props;return a(`p-metergroup-label-list`,{"p-metergroup-label-list-start":t.labelPosition===`start`,"p-metergroup-label-list-end":t.labelPosition===`end`,"p-metergroup-label-list-vertical":t.labelOrientation===`vertical`,"p-metergroup-label-list-horizontal":t.labelOrientation===`horizontal`})},labellistitem:`p-metergroup-label-list-item`,labelicon:`p-metergroup-label-icon`,labellisttype:`p-metergroup-label-type`,label:`p-metergroup-label`},styles:`
@layer primereact {
    .p-metergroup {
        position: relative;
        overflow: hidden;
    }

    .p-metergroup-vertical.p-metergroup {
        display: flex;
    }

    .p-metergroup-vertical .p-metergroup-meter-container {
        flex-direction: column;
    }

    .p-metergroup-meter-container {
        display: flex;
    }

    .p-metergroup-label-list {
        display: flex;
        margin: 0;
        padding: 0;
        list-style-type: none;
    }

    .p-metergroup-vertical .p-metergroup-label-list {
        align-items: start;
    }

    .p-metergroup-label-list-vertical {
        flex-direction: column;
    }

    .p-metergroup-label-list-horizontal {
        flex-direction: row;
    }

    .p-metergroup-label-list-item {
        display: inline-flex;
        align-items: center;
    }

    .p-metergroup-label-type {
        display: inline-block;
    }
}
`}});function v(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function y(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?v(Object(n),!0).forEach(function(t){g(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):v(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}var b=function(e){var t=d.useContext(r),n=_.getProps(e,t),s=n.values,l=n.min,u=n.max,p=n.orientation,m=n.labelPosition,h=n.start,g=n.end,v=n.meter,b=n.labelList,x=o(),S=_.setMetaData(y(y({props:n},n.__parentMetadata),{},{context:{disabled:n.disabled}})),C=S.ptm,w=S.cx,T=S.isUnstyled;c(_.css.styles,T,{name:`metergroup`});var E=0,D=[];s.map(function(e){E+=e.value,D.push(Math.round(e.value/E*100))});var O=function(){var e=((arguments.length>0&&arguments[0]!==void 0?arguments[0]:0)-l)/(u-l)*100;return Math.round(Math.max(0,Math.min(100,e)))},k=x({className:a(n.className,w(`root`,{orientation:p}))},_.getOtherProps(n),C(`root`)),A=function(){var e=s.map(function(e,t){var n=O(e.value),r={backgroundColor:e.color,width:p===`horizontal`?n+`%`:`auto`,height:p===`vertical`?n+`%`:`auto`},a=x({className:w(`meter`),style:r},C(`meter`));if(v||e.meterTemplate){var o=x({className:w(`meter`)},C(`meter`));return i.getJSXElement(e.meterTemplate||v,y(y({},e),{},{percentage:n,index:t}),o)}return d.createElement(`span`,f({key:t},a))}),t=x({className:w(`metercontainer`)},C(`metercontainer`));return d.createElement(`div`,t,e)},j=function(){var e=x({className:w(`labellist`)},C(`labellist`)),t=x({className:w(`labellistitem`)},C(`labellistitem`)),n=x({className:w(`label`)},C(`label`));return d.createElement(`ol`,e,s.map(function(e,r){var i=x({className:a(w(`labelicon`),e.icon),style:{color:e.color}},C(`labelicon`)),o=x({className:w(`labellisttype`),style:{backgroundColor:e.color}},C(`labellisttype`)),s=e.icon?d.createElement(`i`,i):d.createElement(`span`,o),c=O(e.value);return d.createElement(`li`,f({key:r},t),s,d.createElement(`span`,n,e?.label,` `,`(${c}%)`))}))},M={totalPercent:E,percentages:D,values:s},N=b||j(),P=i.getJSXElement(N,{values:s,totalPercent:E});return d.createElement(`div`,f({},k,{role:`meter`,"aria-valuemin":l,"aria-valuemax":u,"aria-valuenow":E}),m===`start`&&P,h&&i.getJSXElement(h,M),A(),g&&i.getJSXElement(g,M),m===`end`&&P)};async function x(){return u(`/server/status`)}var S={container:`_container_1rv16_1`,header:`_header_1rv16_9`,loading:`_loading_1rv16_22`,error:`_error_1rv16_28`,details:`_details_1rv16_37`,detailItem:`_detailItem_1rv16_44`,detailLabel:`_detailLabel_1rv16_50`,detailValue:`_detailValue_1rv16_57`},C=n(),w=[{key:`cpu`,label:`CPU`,color:`#4caf50`},{key:`memory`,label:`RAM`,color:`#2196f3`},{key:`disk`,label:`Disk`,color:`#ff9800`}];function T(){let[e,t]=(0,d.useState)(null),[n,r]=(0,d.useState)(!0),[i,a]=(0,d.useState)(null),o=(0,d.useCallback)(async()=>{try{r(!0),a(null),t(await x())}catch(e){a(e instanceof Error?e.message:`Failed to fetch status`)}finally{r(!1)}},[]);(0,d.useEffect)(()=>{o()},[]),(0,d.useEffect)(()=>{let e=setInterval(o,6e4);return()=>clearInterval(e)},[o]);let s=w.map(t=>({label:t.label,value:e?.[t.key]?.usage_percent??0,color:t.color})),c=t=>{let n=e?.[t];if(!n)return`—`;if(t===`cpu`)return`${n.usage_percent.toFixed(1)}%`;let r=n;return`${r.used_mb} / ${r.total_mb} MB`};return(0,C.jsxs)(`div`,{className:S.container,children:[(0,C.jsxs)(`div`,{className:S.header,children:[(0,C.jsx)(`h2`,{children:`Метрики сервера`}),(0,C.jsx)(l,{icon:`pi pi-refresh`,rounded:!0,text:!0,onClick:o,disabled:n,title:`Обновить`})]}),i&&(0,C.jsx)(`div`,{className:S.error,children:i}),(0,C.jsx)(b,{values:s,min:0,max:100}),(0,C.jsx)(`div`,{className:S.details,children:w.map(e=>(0,C.jsxs)(`div`,{className:S.detailItem,children:[(0,C.jsxs)(`span`,{className:S.detailLabel,children:[e.label,`:`]}),(0,C.jsx)(`span`,{className:S.detailValue,children:c(e.key)})]},e.key))})]})}function E(){return(0,C.jsx)(`div`,{children:(0,C.jsx)(T,{})})}export{E as default};